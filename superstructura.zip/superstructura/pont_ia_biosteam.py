import biosteam as bst
from hydrolyse_neutre import simuler_usine_neutre
from hydrolyse_acide import simuler_usine_acide
from hydrolyse_basique import simuler_usine_basique
from alcoolyse import simuler_usine_alcoolyse

# =========================================================================
# CONFIGURATION GLOBALE ACV (LCA) NATIVE BIOSTEAM (MODE PRO)
# =========================================================================


def generer_flux_sortie_reacteur(masse_pa6_in, masse_eau_in, type_catalyseur, masse_catalyseur, predictions_IA, masse_fibres, nom_solvant="Water"):
    conversion = predictions_IA['Conversion']
    rendement = predictions_IA['Rendement_CPL']
    
    masse_cpl = masse_pa6_in * rendement
    masse_oligomeres = masse_pa6_in * (conversion - rendement)
    masse_pa6_restant = masse_pa6_in * (1 - conversion)
    
    flux = {
        'Caprolactam': masse_cpl,
        'Oligomers': masse_oligomeres,
        'PA6_Solid': masse_pa6_restant,
        'Fibre_Verre': masse_fibres
    }
    
    # CORRECTION CRUCIALE ICI : 
    # On n'ajoute pas l'Isopropanol à 0.0 si on est dans l'eau, pour éviter de faire crasher la thermo !
    if nom_solvant != "Water":
        flux['Isopropanol'] = masse_eau_in 
    else:
        flux['Water'] = masse_eau_in
        
    cat_nom = str(type_catalyseur).upper()
    
    if 'ZRO2' in cat_nom:
        flux['m_ZrO2'] = masse_catalyseur
    elif 'MOF' in cat_nom:
        flux['Fe_MOF_Solid'] = masse_catalyseur
    elif 'H3PO4' in cat_nom or 'HCL' in cat_nom or 'H2SO4' in cat_nom or 'MSA' in cat_nom or 'TSA' in cat_nom or 'BSA' in cat_nom or 'HPA' in cat_nom:
        flux['H3PO4_Acide'] = masse_catalyseur 
    elif 'NAOH' in cat_nom or 'KOH' in cat_nom:
        flux['NaOH_Base'] = masse_catalyseur
        
    return flux

def orchestrateur_usine(flux_biosteam, type_catalyseur, type_reacteur, temp_user, pression_user, temps_sejour, nom_solvant="Water"):
    cat_nom = str(type_catalyseur).upper()
    
    if nom_solvant != "Water":
        return simuler_usine_alcoolyse(flux_biosteam, type_reacteur, temp_user, pression_user, type_catalyseur, temps_sejour, nom_solvant)
    elif 'ZRO2' in cat_nom or 'MOF' in cat_nom or str(type_catalyseur) == '0':
        return simuler_usine_neutre(flux_biosteam, type_reacteur, temp_user, pression_user, type_catalyseur, temps_sejour)
    elif 'H3PO4' in cat_nom or 'HCL' in cat_nom or 'H2SO4' in cat_nom or 'MSA' in cat_nom or 'TSA' in cat_nom or 'BSA' in cat_nom or 'HPA' in cat_nom:
        return simuler_usine_acide(flux_biosteam, type_reacteur, temp_user, pression_user, type_catalyseur, temps_sejour)
    elif 'NAOH' in cat_nom or 'KOH' in cat_nom:
        return simuler_usine_basique(flux_biosteam, type_reacteur, temp_user, pression_user, type_catalyseur, temps_sejour)
    else:
        raise ValueError(f"ERREUR : Catalyseur '{type_catalyseur}' inconnu dans l'orchestrateur !")