import thermosteam as tmo
import biosteam as bst

# =========================================================================
# 1. INITIALISATION THERMODYNAMIQUE (Spéciale Alcoolyse)
# =========================================================================
# On utilise l'Isopropanol (2-Propanol) comme solvant thermodynamique de référence (Proxy)
Isopropanol = bst.Chemical('Isopropanol')
CPL = bst.Chemical('Caprolactam')
Water = bst.Chemical('Water') 

# Clones physiques pour les solides et liquides lourds
PA6 = bst.Chemical('Glycerol').copy('PA6_Solid')
Oligomers = bst.Chemical('Glycerol').copy('Oligomers')
Catalyseur_Solide = bst.Chemical('Glycerol').copy('Catalyseur_Solide')
Fibre_Verre = bst.Chemical('Glycerol').copy('Fibre_Verre')

chemin_chimique = bst.Chemicals([
    Isopropanol, CPL, Water, PA6, Oligomers, Catalyseur_Solide, Fibre_Verre
])
bst.settings.set_thermo(chemin_chimique)
CPL.smiles = 'C1CCC(=O)NCC1'

# =========================================================================
# 2. L'USINE COMPLÈTE (ARCHITECTURE KAMIMURA 2005 vs 2007)
# =========================================================================
def simuler_usine_alcoolyse(flux_masses_dictionnaire, type_reacteur, temp_user, pression_user, nom_catalyseur, temps_sejour, nom_solvant):
    bst.main_flowsheet.clear() 
    bst.settings.set_thermo(chemin_chimique)
    
    # --- DÉTECTION DU TYPE D'ALCOOL (Kamimura 2005) ---
    # Les alcools secondaires et cycliques permettent une séparation facile par évaporation
    ALCOOLS_FACILES = ["2-Propanol", "2-Butanol", "Cyclohexanol", "Cyclododecanol", "2-Methyl-2-propanol"]
    est_alcool_secondaire = any(alc.lower() in str(nom_solvant).lower() for alc in ALCOOLS_FACILES)
    
    # --- BLOC 0 : PRÉPARATION ET RÉACTEUR ---
    soupe_froide = bst.Stream('Melange_PA6_Alcool', **flux_masses_dictionnaire, units='kg/hr', T=25+273.15, P=pression_user * 1000)
    H1_Prechauffage = bst.HXutility('H1_Prechauffage', ins=soupe_froide, outs='Soupe_Chaude', T=temp_user+273.15)
    
    R101_Reacteur = bst.Mixer('R101_Reacteur', ins=H1_Prechauffage.outs[0], outs='Jus_Reactionnel')
    
    # --- BLOC 1 : DÉSALCOOLISATION (Flash Separation) ---
    V1_Valve = bst.IsenthalpicValve('V1_Detente', ins=R101_Reacteur.outs[0], outs='Jus_Detendu', P=101325) # 1 atm
    H2_Flash = bst.HXutility('H2_Flash_Heater', ins=V1_Valve.outs[0], outs='Jus_A_Flasher', T=140+273.15)
    
    Flash_Desalcoolisation = bst.Splitter('Flash_Desalcoolisation', ins=H2_Flash.outs[0], outs=('Vapeur_Alcool', 'Jus_Lourd'), 
                             split={'Isopropanol': 0.999, 'Water': 0.99, 'Caprolactam': 0.01, 'PA6_Solid': 0.0, 'Oligomers': 0.0, 'Catalyseur_Solide': 0.0, 'Fibre_Verre': 0.0})
    
    C1_Condenseur = bst.HXutility('C1_Condenseur_Alcool', ins=Flash_Desalcoolisation.outs[0], outs='Alcool_Liquide', T=40+273.15)
    Purge_Alcool = bst.Splitter('Purge_Alcool', ins=C1_Condenseur.outs[0], outs=('Alcool_Recycle', 'Purge_Dechets_Legers'), split=0.98)
    
    C2_Refroidissement = bst.HXutility('C2_Cooler', ins=Flash_Desalcoolisation.outs[1], outs='Jus_Froid', T=80+273.15)
    
    # --- AIGUILLAGE DE LA SÉPARATION SELON L'ALCOOL ---
    if est_alcool_secondaire:
        # ROUTE A : Alcool Secondaire (Séparation Idéale - Kamimura 2005)
        # Un simple filtre suffit à retirer les fibres de verre et le PA6 non réagi. Le reste est du CPL très pur !
        Filtre_Solides = bst.Splitter('Filtre_Solides', ins=C2_Refroidissement.outs[0], outs=('Dechets_Solides', 'CPL_Pur'), 
                              split={'PA6_Solid': 1.0, 'Catalyseur_Solide': 1.0, 'Fibre_Verre': 1.0, 'Oligomers': 1.0, 'Caprolactam': 0.01, 'Isopropanol': 0.0, 'Water': 0.0})
        
        masse_cpl_pur = Filtre_Solides.outs[1].imass['Caprolactam']
        masse_totale_sortie = Filtre_Solides.outs[1].F_mass
        masse_sels_toxiques = Filtre_Solides.outs[0].F_mass
        
        # CAPEX très faible car on n'a pas besoin de tour de distillation sous vide
        cout_reste_usine = 450000 * (soupe_froide.F_mass / 10000)**0.6 
        
    else:
        # ROUTE B : Alcool Primaire (Mélange complexe inséparable)
        Filtre_Solides = bst.Splitter('Filtre_Solides', ins=C2_Refroidissement.outs[0], outs=('Dechets_Solides', 'Jus_Filtre'), 
                              split={'PA6_Solid': 1.0, 'Catalyseur_Solide': 1.0, 'Fibre_Verre': 1.0, 'Oligomers': 0.0, 'Caprolactam': 0.0})
                              
        # Le CPL est prisonnier des oligomères et des restes de produits décomposés.
        # On simule cette catastrophe avec un Splitter qui gâche le produit (40% de CPL perdu).
        Purification_Finale = bst.Splitter('Purification_Finale', ins=Filtre_Solides.outs[1], outs=('CPL_Impur', 'Fractions_Lourdes_Inséparables'), 
                              split={'Caprolactam': 0.60, 'Oligomers': 0.90, 'Isopropanol': 0.50, 'Water': 0.50, 'PA6_Solid': 0.0})
                              
        masse_cpl_pur = Purification_Finale.outs[0].imass['Caprolactam']
        masse_totale_sortie = Purification_Finale.outs[0].F_mass
        masse_sels_toxiques = Filtre_Solides.outs[0].F_mass + Purification_Finale.outs[1].F_mass
        
        # CAPEX très élevé (tentatives de distillation complexes)
        cout_reste_usine = 2500000 * (soupe_froide.F_mass / 10000)**0.6 

    # =====================================================================
    # CRÉATION ET SIMULATION
    # =====================================================================
    systeme_alcoolyse = bst.main_flowsheet.create_system('Usine_Alcoolyse_Kamimura')
    systeme_alcoolyse.simulate() 

    # =====================================================================
    # CALCUL DES INDICATEURS ÉCONOMIQUES (KPI) ET ENVIRONNEMENTAUX (ACV)
    # =====================================================================
    try:
        # 1. ÉNERGIE THERMIQUE (Bypass Heuristique pour la haute température)
        masse_entree_totale = soupe_froide.F_mass
        cp_moyen = 3.0 # Capacité thermique moyenne (kJ/kg/K)
        delta_t = max(0.0, temp_user - 25.0) 
        
        energie_chaude_theorique_kJ = masse_entree_totale * cp_moyen * delta_t
        energie_chaude_kJ = energie_chaude_theorique_kJ * 1.2 # +20% pertes thermiques
        
        cout_vapeur_hr = (energie_chaude_kJ / 1000.0) * 0.005 
        cout_eau_froide_hr = (energie_chaude_kJ / 1000.0) * 0.0005
        
        # 2. CAPEX (Coût des Équipements)
        volume_reacteur_m3 = (masse_entree_totale / 800.0) * temps_sejour 
        cout_base_reacteur = 350000 
        cout_reacteur_extrapole = cout_base_reacteur * (max(volume_reacteur_m3, 0.5) / 5.0)**0.6
        
        multiplicateur_pression = 1.0
        if pression_user > 10000: multiplicateur_pression = 2.5
        if pression_user > 25000: multiplicateur_pression = 4.0
        cout_reacteur_extrapole *= multiplicateur_pression
        
        capex_total = cout_reacteur_extrapole + cout_reste_usine
        cout_equipement_hr = capex_total / (10 * 8000)
        
        # 3. DÉCHETS ET MATIÈRES (LA LIGNE QUI MANQUAIT EST ICI !)
        masse_eaux_usees = Purge_Alcool.outs[1].F_mass 
        
        masse_alcool_total = soupe_froide.imass['Isopropanol']
        masse_appoint_neuf = masse_alcool_total * 0.02 # 2% de pertes
        
        prix_solvant = 1.60 if est_alcool_secondaire else 0.80
        cout_solvant_hr = masse_appoint_neuf * prix_solvant 
        cout_cata_hr = flux_masses_dictionnaire.get('Catalyseur_Solide', 0) * 1.50

        purete_finale = (masse_cpl_pur / masse_totale_sortie) * 100.0 if masse_totale_sortie > 0 else 0.0
        
        # 4. ACV MANUELLE SÉCURISÉE (GWP)
        # 4. ACV MANUELLE SÉCURISÉE (GWP)
        energie_chaude_MJ = energie_chaude_kJ / 1000.0
        energie_froide_MJ = energie_chaude_kJ / 1000.0 # On refroidit la même quantité
        
        gwp_vapeur = energie_chaude_MJ * 0.263  
        gwp_froid = energie_froide_MJ * 0.117    
        gwp_solvant = masse_appoint_neuf * 2.50  
        
        emissions_totales_kgCO2_hr = gwp_vapeur + gwp_froid + gwp_solvant
        
        # --- CORRECTION ICI ---
        # On n'utilise plus la sortie BioSTEAM (qui peut être vidée par un bug thermo)
        # On utilise la masse de CPL envoyée par l'Intelligence Artificielle !
        masse_cpl_theorique = flux_masses_dictionnaire.get('Caprolactam', 0.0)
        
        if masse_cpl_theorique > 0:
            gwp_final = emissions_totales_kgCO2_hr / masse_cpl_theorique
        else:
            gwp_final = 0.0
        # ----------------------

        # 5. RETOUR DES KPI
        return {
            "Cout_Vapeur_hr": cout_vapeur_hr, 
            "Cout_Eau_Froide_hr": cout_eau_froide_hr,
            "Eaux_Usees_kg": masse_eaux_usees,           
            "Dechets_Toxiques_kg": masse_sels_toxiques,  
            "Cout_Equipement_hr": cout_equipement_hr, 
            "Cout_Solvant_hr": cout_solvant_hr,
            "Cout_Reactifs_hr": 0.0,
            "Cout_Catalyseur_hr": cout_cata_hr,
            "Purete_CPL": purete_finale,
            "Type_Usine": "Alcoolyse",
            "GWP_kgCO2_per_kgCPL": gwp_final
        }
        
    except Exception as e:
        print(f"Erreur interne KPI : {e}")
        return {"Cout_Vapeur_hr": 0, "Cout_Eau_Froide_hr": 0, "Eaux_Usees_kg": 0, "Dechets_Toxiques_kg": 0, "Cout_Equipement_hr": 0, "Cout_Solvant_hr": 0, "Cout_Reactifs_hr": 0, "Purete_CPL": 0, "Type_Usine": "Erreur", "GWP_kgCO2_per_kgCPL": 0.0}