import thermosteam as tmo
import biosteam as bst

# =========================================================================
# 1. INITIALISATION THERMODYNAMIQUE GLOBALE
# =========================================================================
Water = bst.Chemical('Water')
CPL = bst.Chemical('Caprolactam')
Cyclohexanol = bst.Chemical('Cyclohexanol')
Toluene = bst.Chemical('Toluene')

PA6 = bst.Chemical('Glycerol').copy('PA6_Solid')
Catalyseur_Solide = bst.Chemical('Glycerol').copy('m_ZrO2')
Fe_MOF_Solid = bst.Chemical('Glycerol').copy('Fe_MOF_Solid') 
Oligomers = bst.Chemical('Glycerol').copy('Oligomers')
Fibre_Verre = bst.Chemical('Glycerol').copy('Fibre_Verre')

H3PO4_Acide = bst.Chemical('Glycerol').copy('H3PO4_Acide')
NaOH_Base = bst.Chemical('Glycerol').copy('NaOH_Base')
Na3PO4_Sel = bst.Chemical('Glycerol').copy('Na3PO4_Sel')

chemin_chimique = bst.Chemicals([
    Water, CPL, Cyclohexanol, Toluene, Oligomers, PA6, 
    Catalyseur_Solide, Fe_MOF_Solid, Fibre_Verre, 
    H3PO4_Acide, NaOH_Base, Na3PO4_Sel
])
bst.settings.set_thermo(chemin_chimique)
CPL.smiles = 'C1CCC(=O)NCC1'

# =========================================================================
# 2. L'USINE COMPLÈTE (ARCHITECTURE DYNAMIQUE)
# =========================================================================
def simuler_usine_acide(flux_masses_dictionnaire, type_reacteur, temp_user, pression_user, nom_catalyseur, temps_sejour):
    bst.main_flowsheet.clear() 
    bst.settings.set_thermo(chemin_chimique)
    
    # Préparation commune
    soupe_froide = bst.Stream('Soupe_Froide', **flux_masses_dictionnaire, units='kg/hr', T=25+273.15, P=pression_user * 1000)
    soupe_prechauffee = soupe_froide.copy()
    soupe_prechauffee.T = 25 + (temp_user - 25) * 0.85 + 273.15
    H1_Trim = bst.HXutility('H1_Trim_Heater', ins=soupe_prechauffee, outs='Soupe_Chaude', T=temp_user+273.15)
    
    # Variables pour les bilans (initialisées à zéro)
    energie_flash = 0
    energie_condenseur = 0
    masse_appoint_neuf = 0
    masse_eaux_usees = 0

    # -----------------------------------------------------------------
    # EMBRANCHEMENT INTELLIGENT DE L'USINE
    # -----------------------------------------------------------------
    if "Steam-sparged" in type_reacteur:
        # ARCHITECTURE A : STRIPPING VAPEUR (Séparation directe, sans Toluène)
        
        R101 = bst.Splitter('R101_Stripping', ins=H1_Trim.outs[0], outs=('Vapeur_Produit', 'Liquide_Dechets'), 
                            split={'Water': 0.99, 'Caprolactam': 0.98, 'H3PO4_Acide': 0.0, 'PA6_Solid': 0.0, 'Oligomers': 0.0, 'Fibre_Verre': 0.0})
        
        # Le produit gazeux pur part directement au condenseur
        C1_Condenseur = bst.HXutility('C1_Condenseur', ins=R101.outs[0], outs='CPL_Aqueux', T=60+273.15)
        Cristaux = bst.Splitter('Cristaux', ins=C1_Condenseur.outs[0], outs=('CPL_Pur', 'Eau_Evaporee'), split={'Caprolactam': 0.98, 'Water': 0.01})
        
        # Le fond liquide part à la neutralisation
        C2_Quench = bst.HXutility('C2_Quench_Dechets', ins=R101.outs[1], outs='Dechets_Froids', T=80+273.15)
        masse_acide_presente = flux_masses_dictionnaire.get('H3PO4_Acide', 0)
        flux_soude = bst.Stream('Flux_Soude_Achetee', NaOH_Base=masse_acide_presente * 1.2, units='kg/hr', T=25+273.15)
        
        Cuve_Neutralisation = bst.Mixer('Cuve_Neutralisation', ins=(C2_Quench.outs[0], flux_soude), outs=('Jus_Neutralise',))
        Filtre_Sels = bst.Splitter('Filtre_Sels', ins=Cuve_Neutralisation.outs[0], outs=('Dechets_Solides', 'Jus_Clair'), 
                                   split={'PA6_Solid': 1.0, 'Fibre_Verre': 1.0, 'H3PO4_Acide': 1.0, 'NaOH_Base': 1.0, 'Na3PO4_Sel': 1.0, 'Water': 0.0, 'Caprolactam': 0.0})
        
        energie_quench = C2_Quench.ins[0].H - C2_Quench.outs[0].H
        energie_chiller = C1_Condenseur.ins[0].H - C1_Condenseur.outs[0].H
        cout_multiplicateur_capex = 1.0 # Usine simple
        masse_eaux_usees = Filtre_Sels.outs[1].F_mass + Cristaux.outs[1].F_mass

    else:
        # ARCHITECTURE B : CLOSED LOOP (Mélange total -> Extraction au Toluène obligatoire)
        
        R101 = bst.Mixer('R101_Closed_Loop', ins=H1_Trim.outs[0], outs='Jus_Reacteur')
        C1_Quench = bst.HXutility('C1_Quench_Cooler', ins=R101.outs[0], outs='Soupe_Quench', T=80+273.15)
        
        masse_acide_presente = flux_masses_dictionnaire.get('H3PO4_Acide', 0)
        flux_soude = bst.Stream('Flux_Soude_Achetee', NaOH_Base=masse_acide_presente * 1.2, units='kg/hr', T=25+273.15)
        
        Cuve_Neutralisation = bst.Mixer('Cuve_Neutralisation', ins=(C1_Quench.outs[0], flux_soude), outs=('Jus_Neutralise',))
        Filtre_Sels = bst.Splitter('Filtre_Sels', ins=Cuve_Neutralisation.outs[0], outs=('Dechets_Solides', 'Jus_Clair'), 
                                   split={'PA6_Solid': 1.0, 'Fibre_Verre': 1.0, 'H3PO4_Acide': 1.0, 'NaOH_Base': 1.0, 'Na3PO4_Sel': 1.0, 'Water': 0.0, 'Caprolactam': 0.0})
        
        # Boucle d'extraction au Solvant
        solvant_total_requis = soupe_froide.F_mass * 0.5 
        solvant = bst.Stream('Solv_Toluene', Toluene=solvant_total_requis, units='kg/hr', T=55+273.15)
        Mix = bst.Mixer('Mix', ins=(Filtre_Sels.outs[1], solvant), outs=('Melange',))
        
        ELL = bst.Splitter('ELL', ins=Mix.outs[0], outs=('Org', 'Aq'), 
                           split={'Toluene': 0.99, 'Caprolactam': 0.95, 'Water': 0.05, 'Oligomers': 0.01})
        
        H2_Reboiler = bst.HXutility('H2_Reboiler', ins=ELL.outs[0], outs='Org_Chaud', T=150+273.15)
        Flash = bst.Splitter('Flash', ins=H2_Reboiler.outs[0], outs=('Vapeur_Solvant', 'CPL_Brut'), 
                             split={'Toluene': 0.99, 'Caprolactam': 0.01, 'Water': 0.99, 'Oligomers': 0.0})
        
        C2_Condenser = bst.HXutility('C2_Condenser', ins=Flash.outs[0], outs='Solvant_Froid', T=55+273.15)
        Purge = bst.Splitter('Purge', ins=C2_Condenser.outs[0], outs=('Solv_Recycle', 'Purge_Dechets'), split=1.0 - (1/50))
        masse_appoint_neuf = max(0.0, solvant_total_requis - Purge.outs[0].imass['Toluene'])
        
        C3_Chiller = bst.HXutility('C3_Chiller', ins=Flash.outs[1], outs='CPL_Froid', T=60+273.15)
        Cristaux = bst.Splitter('Cristaux', ins=C3_Chiller.outs[0], outs=('CPL_Pur', 'Dechets_Liq'), 
                                split={'Caprolactam': 0.98, 'Toluene': 0.001, 'Water': 0.001})
        
        energie_quench = C1_Quench.ins[0].H - C1_Quench.outs[0].H
        energie_flash = H2_Reboiler.outs[0].H - H2_Reboiler.ins[0].H
        energie_condenseur = C2_Condenser.ins[0].H - C2_Condenser.outs[0].H
        energie_chiller = C3_Chiller.ins[0].H - C3_Chiller.outs[0].H
        cout_multiplicateur_capex = 1.3 # Usine plus complexe car ajout de la boucle solvant
        masse_eaux_usees = ELL.outs[1].F_mass + Cristaux.outs[1].F_mass + Purge.outs[1].F_mass

    # -----------------------------------------------------------------
    # SIMULATION GLOBALE (BioSTEAM compile l'architecture choisie)
    # -----------------------------------------------------------------
    mon_systeme_complet = bst.main_flowsheet.create_system('Usine_Acide_Dynamique')
    mon_systeme_complet.simulate() 
    
    chemin_absolu = r"c:\Users\mathi\Desktop\Stage_Nylon\python\process\Mon_Flowsheet_Acide"
    mon_systeme_complet.diagram(format='png', file=chemin_absolu)

    # -----------------------------------------------------------------
    # CALCUL DES KPI ÉCONOMIQUES
    # -----------------------------------------------------------------
    # -----------------------------------------------------------------
    # CALCUL DES KPI ÉCONOMIQUES ET ENVIRONNEMENTAUX (ACV)
    # -----------------------------------------------------------------
    try:
        # --- 1. ÉNERGIE THERMIQUE (Bypass Heuristique) ---
        masse_entree_totale = soupe_froide.F_mass 
        # Heuristique : Le solvant majoritaire est l'eau (Cp ~ 4.18 kJ/kg/K)
        cp_moyen = 4.18 
        delta_t = max(0.0, temp_user - 25.0)
        
        energie_prechauffage_theorique_kJ = masse_entree_totale * cp_moyen * delta_t * 1.2 # +20% de pertes
        
        # On additionne l'heuristique (pour le réacteur) avec l'énergie du flash (qui fonctionne car basse température)
        energie_chaude_totale_kJ = energie_prechauffage_theorique_kJ + abs(energie_flash)
        energie_froide_totale_kJ = energie_chaude_totale_kJ # On dissipe autant qu'on chauffe pour sécuriser la thermo
        
        cout_vapeur_hr = (energie_chaude_totale_kJ / 1000.0) * 0.005
        cout_eau_froide_hr = (energie_froide_totale_kJ / 1000.0) * 0.0005
        
        # --- 2. CAPEX DYNAMIQUE ---
        volume_reacteur_m3 = (masse_entree_totale / 950.0) * temps_sejour
        
        cout_reacteur_extrapole = 350000 * (max(volume_reacteur_m3, 0.5) / 5.0)**0.6
        cout_reste_usine = 2150000 * (masse_entree_totale / 10000)**0.6
        
        capex_total = (cout_reacteur_extrapole + cout_reste_usine) * cout_multiplicateur_capex
        cout_equipement_hr = capex_total / (10 * 8000)
        
        # --- 3. DÉCHETS, SOLVANTS ET RÉACTIFS ---
        masse_sels_toxiques = Filtre_Sels.outs[0].F_mass
        cout_solvant_hr = masse_appoint_neuf * 1.50 
        
        masse_soude_achetee = masse_acide_presente * 1.2
        cout_soude_hr = masse_soude_achetee * 0.30 
        
        PRIX_CATALYSEURS = {"H3PO4": 0.80, "HCl": 0.15, "H2SO4": 0.20, "MSA": 2.50, "p-TSA": 1.20, "H3PW12O40 HPA": 45.00}
        cout_cata_hr = masse_acide_presente * PRIX_CATALYSEURS.get(nom_catalyseur, 1.0)

        
        
        masse_cpl_pur = Cristaux.outs[0].imass['Caprolactam']
        masse_totale_sortie = Cristaux.outs[0].F_mass
        purete_finale = (masse_cpl_pur / masse_totale_sortie) * 100.0 if masse_totale_sortie > 0 else 0.0

        # --- 4. ACV MANUELLE SÉCURISÉE (GWP) ---
        energie_chaude_MJ = energie_chaude_totale_kJ / 1000.0
        energie_froide_MJ = energie_froide_totale_kJ / 1000.0
        
        # Facteurs d'Émission Ecoinvent
        gwp_vapeur = energie_chaude_MJ * 0.263   # Gaz naturel
        gwp_froid = energie_froide_MJ * 0.117    # Pompes élec
        gwp_solvant = masse_appoint_neuf * 2.50  # Synthèse Toluène (si architecture Closed Loop)
        
        # Impact de la chimie : L'Acide en entrée + La Soude de neutralisation !
        gwp_catalyseur_acide = masse_acide_presente * 1 # Proxy moyen pour la production d'acides industriels
        gwp_base_neutralisation = masse_soude_achetee * 0.458 # Production de la Soude (Électrolyse chlore-soude)
        
        emissions_totales_kgCO2_hr = gwp_vapeur + gwp_froid + gwp_solvant + gwp_catalyseur_acide + gwp_base_neutralisation
        
        # Utilisation de la masse théorique IA pour esquiver les "Silent Failures" de BioSTEAM
        masse_cpl_theorique = flux_masses_dictionnaire.get('Caprolactam', 0.0)
        
        if masse_cpl_theorique > 0:
            gwp_final = emissions_totales_kgCO2_hr / masse_cpl_theorique
        else:
            gwp_final = 0.0
        # =====================================================================

        return {
            "Cout_Vapeur_hr": cout_vapeur_hr, 
            "Cout_Eau_Froide_hr": cout_eau_froide_hr,
            "Eaux_Usees_kg": masse_eaux_usees,           
            "Dechets_Toxiques_kg": masse_sels_toxiques,  
            "Cout_Equipement_hr": cout_equipement_hr, 
            "Cout_Solvant_hr": cout_solvant_hr,
            "Cout_Reactifs_hr": cout_soude_hr,           # <-- Prise en compte du coût de la soude achetée
            "Cout_Catalyseur_hr": cout_cata_hr,          # <-- Coût de l'acide
            "Purete_CPL": purete_finale,
            "Type_Usine": "Hydrolyse Acide",
            "GWP_kgCO2_per_kgCPL": gwp_final
        }
        
    except Exception as e:
        print(f"Erreur interne KPI : {e}")
        return {"Cout_Vapeur_hr": 0, "Cout_Eau_Froide_hr": 0, "Eaux_Usees_kg": 0, "Dechets_Toxiques_kg": 0, "Cout_Equipement_hr": 0, "Cout_Solvant_hr": 0, "Cout_Reactifs_hr": 0, "Cout_Catalyseur_hr": 0, "Purete_CPL": 0, "Type_Usine": "Erreur", "GWP_kgCO2_per_kgCPL": 0.0}