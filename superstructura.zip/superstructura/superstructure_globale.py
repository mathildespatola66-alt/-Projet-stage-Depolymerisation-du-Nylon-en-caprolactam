import pandas as pd
import numpy as np
import random
import math
import sys
import os
from random_forest import charger_et_preparer_donnees, entrainer_expert, DOSSIER_TRAVAIL
from pont_ia_biosteam import generer_flux_sortie_reacteur, orchestrateur_usine
import warnings
warnings.filterwarnings('ignore')

REACTEURS_BIBLIO = {
    "H3PO4": ["Closed loop reactor", "Steam-sparged stirred vessel"],
    "H3PW12O40 HPA": ["Batch"],
    "Fe- MOF-1": ["High-pressure reaction kettle"],
    "Fe- MOF-2": ["High-pressure reaction kettle"],
    "m-ZrO2": ["Autoclave batch"],
    "0": ["Batch", "Autoclave batch"],
    "NaOH-KOH": ["Closed loop reactor"],
    "NaOH": ["Batch"],
    "HCl": ["Batch"],
    "H2SO4": ["Batch"],
    "MSA": ["Batch"],
    "p-TSA": ["Batch"],
    "BSA": ["Batch"]
}

ALCOOLS_AUTOCLAVE = [
    "Methanol", "EtOH", "1-Propanol", "2-Propanol", 
    "1-Butanol", "2-Butanol", "2-Methyl-1-propanol", "2-Methyl-2-propanol"
]

ALCOOLS_BATCH = [
    "1-Pentanol", "2.2-Dimethyl-1-propanol", "1-Hexanol", "Cyclohexanol", 
    "1-Heptanol", "1-Octanol", "1-Decanol", "Dodecanol", "Cyclododecanol"
]

# =========================================================================
# LES LOIS DE LA PHYSIQUE ET DE LA MÉCANIQUE
# =========================================================================
def obtenir_limites_physiques(proc, cat, reacteur):
    """
    Renvoie les bornes (T_min, T_max, P_min, P_max) et un flag indiquant
    s'il faut imposer l'état d'eau sous-critique (liquide)
    """
    is_liquid_water = False
    p_min, p_max = 101.3, 101.3
    t_min, t_max = 200.0, 300.0

    if "alcoholysis" in proc.lower() or "glycolysis" in proc.lower():
        if "Autoclave" in reacteur:
            t_min, t_max = 250.0, 400.0
            p_min, p_max = 5000.0, 30000.0 # Pression Autogène Supercritique
        else:
            t_min, t_max = 150.0, 260.0 # Limite de reflux des alcools lourds
            p_min, p_max = 101.3, 500.0 # Cuve ouverte classique
            
    elif "Acidic" in proc:
        if "H3PO4" in cat:
            t_min, t_max = 210.0, 370.0
            if "Steam-sparged" in reacteur:
                p_min, p_max = 500.0, 3500.0 # Stripping vapeur : Pression modérée
            else:
                is_liquid_water = True # Closed loop : Eau liquide forcée
        elif cat in ["HCl", "H2SO4", "MSA", "p-TSA", "BSA"]:
            t_min, t_max = 100.0, 150.0
            p_min, p_max = 101.3, 500.0
        elif "HPA" in cat:
            t_min, t_max = 280.0, 330.0
            p_min, p_max = 8000.0, 10000.0
            
    elif "Neutral" in proc:
        if cat == "0":
            t_min, t_max = 250.0, 400.0
            is_liquid_water = True
        elif "ZrO2" in cat:
            t_min, t_max = 180.0, 230.0
            is_liquid_water = True
        elif "MOF" in cat:
            t_min, t_max = 220.0, 260.0
            p_min, p_max = 2000.0, 5000.0
            
    elif "Alkaline" in proc:
        is_liquid_water = True
        if "NaOH-KOH" in cat:
            t_min, t_max = 290.0, 350.0
        else:
            t_min, t_max = 225.0, 270.0
            
    return t_min, t_max, p_min, p_max, is_liquid_water

def creer_ligne_ia(features, proc, cat, reacteur, temp, press, time, cat_val, solvant, additif_nom, additif_val, liq_ratio):
    ligne = {col: 0.0 for col in features}
    for col in features:
        col_low = col.lower()
        if 'reactor' not in col_low and 'process' not in col_low and 'type' not in col_low:
            if 'temp' in col_low or 'ºc' in col_low: ligne[col] = temp
            elif 'press' in col_low or 'kpa' in col_low: ligne[col] = press
            elif 'time' in col_low or 'h)' in col_low: ligne[col] = time
            elif 'liq' in col_low or 'ml/g' in col_low: ligne[col] = liq_ratio
            elif 'wt%' in col_low and 'add' not in col_low: ligne[col] = cat_val
            elif 'wt%' in col_low and 'add' in col_low: ligne[col] = additif_val

        if str(proc) in col or str(proc).replace(" ", "_") in col: ligne[col] = 1.0
        if str(cat) in col and 'type' in col_low: ligne[col] = 1.0
        if str(reacteur) in col: ligne[col] = 1.0
        if str(solvant) != 'Water' and str(solvant).lower() in col_low: ligne[col] = 1.0
        if str(additif_nom) != '0' and col.endswith(str(additif_nom)): ligne[col] = 1.0
        
        if 'cl' in col_low and not 'hcl' in col_low and not 'auto' in col_low and not 'closed' in col_low:
            if 'target' in col_low or 'product' in col_low: ligne[col] = 1.0
    return ligne

def lancer_superstructure_globale():
    df, features, scaler, structure = charger_et_preparer_donnees()
    if df is None: return

    print("\n" + "="*80)
    print(" SUPERSTRUCTURE  ")
    print("="*80)

    try:
        purete_pa6 = float(input("\n -> What is the purity of the incoming plastic waste (%) ? [10-100] : "))
    except ValueError:
        purete_pa6 = 60.0

    try:
        iter_per_proc = int(input(" -> How many initial exploration scenarios per process (ex: 1000) ? : "))
    except ValueError:
        iter_per_proc = 1000

    procs = list(structure.keys())
    tous_les_gagnants_mondiaux = []

    for proc in procs:
        print("\n" + "x"*70)
        print(f"  DEPLOYMENT OF THE DIGITAL TWIN: {proc.replace('_', ' ').upper()}")
        print("x"*70)
        
        expert = entrainer_expert(proc, df, features)
        if expert is None: continue
        
        catalyseurs_possibles = structure[proc]
        scenarios_explores = []

        # --- PHASE 1 : EXPLORATION ---
        print(f"\n   [1/3] Random Exploration Under Physical Constraints ({iter_per_proc} scenarios)...")
        for i in range(iter_per_proc):
            if i > 0 and i % 100 == 0:
                sys.stdout.write(f"\r      Progress : {i} / {iter_per_proc}")
                sys.stdout.flush()

            cat_choisi = str(random.choice(catalyseurs_possibles))
            reacteur_choisi = str(random.choice(REACTEURS_BIBLIO.get(cat_choisi, ["Batch"])))
            
            if "alcoholysis" in proc.lower() or "glycolysis" in proc.lower():
                solvant_choisi = str(random.choice(ALCOOLS_AUTOCLAVE)) if "Autoclave" in reacteur_choisi else str(random.choice(ALCOOLS_BATCH))
            else:
                solvant_choisi = "Water"

            # -----------------------------------------------------
            # APPLICATION DES RÈGLES THERMODYNAMIQUES STRICTES
            # -----------------------------------------------------
            t_min, t_max, p_min_base, p_max_base, is_liquid = obtenir_limites_physiques(proc, cat_choisi, reacteur_choisi)
            temp = random.uniform(t_min, t_max)
            
            if is_liquid:
                p_sat_bar = math.exp(11.68 - 3816.44 / (temp + 227.02))
                p_min = (p_sat_bar * 100) + 200  # P_sat + 2 bars de marge minimum
                p_max = (p_sat_bar * 100) + 5000 # Jusqu'à +50 bars
            else:
                p_min, p_max = p_min_base, p_max_base
                
            press = random.uniform(p_min, p_max)
            
            time = random.uniform(0.5, 6.0)
            cat_val = 0.0 if cat_choisi == "0" else random.uniform(0.1, 10.0)
            liq_ratio = random.uniform(0.5, 5.0)

            ligne = creer_ligne_ia(features, proc, cat_choisi, reacteur_choisi, temp, press, time, cat_val, solvant_choisi, "0", 0.0, liq_ratio)
            df_test = pd.DataFrame([ligne], columns=features)
            scaled = scaler.transform(df_test)
            rendement = expert.predict(pd.DataFrame(scaled, columns=features))[0]
            
            scenarios_explores.append({
                "Procédé": proc.replace('_', ' '), "Catalyseur": cat_choisi, "Réacteur": reacteur_choisi,
                "Solvant": solvant_choisi, "Temp (°C)": temp, "Temps (h)": time, "Cat (wt%)": cat_val,
                "Pression (KPa)": press, "Ratio Liq": liq_ratio, "Rendement IA (%)": rendement,
                "t_min": t_min, "t_max": t_max, "p_min_base": p_min_base, "p_max_base": p_max_base, "is_liquid": is_liquid
            })
        print(f"\r      Progression : {iter_per_proc} / {iter_per_proc} [Terminé]")

        # --- PHASE 2 
        print(f"   [2/3] ..")
        top_10_local = sorted(scenarios_explores, key=lambda x: x["Rendement IA (%)"], reverse=True)[:10]
        mutants_locaux = []
        
        for parent in top_10_local:
            for m in range(50):
                new_temp = max(parent["t_min"], min(parent["t_max"], parent["Temp (°C)"] + random.uniform(-10.0, 10.0)))
                
                if parent["is_liquid"]:
                    p_sat_bar = math.exp(11.68 - 3816.44 / (new_temp + 227.02))
                    p_min = (p_sat_bar * 100) + 200
                    p_max = (p_sat_bar * 100) + 5000
                else:
                    p_min, p_max = parent["p_min_base"], parent["p_max_base"]
                    
                new_press = max(p_min, min(p_max, parent["Pression (KPa)"] + random.uniform(-500.0, 500.0)))
                new_time = max(0.1, min(6.0, parent["Temps (h)"] + random.uniform(-0.5, 0.5)))
                new_cat_val = 0.0 if parent["Catalyseur"] == "0" else max(0.1, min(10.0, parent["Cat (wt%)"] + random.uniform(-1.0, 1.0)))
                new_liq_ratio = max(0.5, min(5.0, parent["Ratio Liq"] + random.uniform(-0.5, 0.5)))
                
                ligne = creer_ligne_ia(features, proc, parent["Catalyseur"], parent["Réacteur"], new_temp, new_press, new_time, new_cat_val, parent["Solvant"], "0", 0.0, new_liq_ratio)
                df_test = pd.DataFrame([ligne], columns=features)
                scaled = scaler.transform(df_test)
                rendement_mutant = expert.predict(pd.DataFrame(scaled, columns=features))[0]
                
                # Note : pas besoin d'ajouter t_min/t_max ici car les mutants ne se reproduisent pas
                mutants_locaux.append({
                    "Procédé": parent["Procédé"], "Catalyseur": parent["Catalyseur"], "Réacteur": parent["Réacteur"],
                    "Solvant": parent["Solvant"], "Temp (°C)": new_temp, "Temps (h)": new_time, "Cat (wt%)": new_cat_val,
                    "Pression (KPa)": new_press, "Ratio Liq": new_liq_ratio, "Rendement IA (%)": rendement_mutant
                })
                
        # On regroupe les parents et les mutants, et on nettoie les clés inutiles
        tous_les_candidats = top_10_local + mutants_locaux
        for c in tous_les_candidats:
            c.pop("t_min", None)
            c.pop("t_max", None)
            c.pop("p_min_base", None)
            c.pop("p_max_base", None)
            c.pop("is_liquid", None)
            
        elite_locale = sorted(tous_les_candidats, key=lambda x: x["Rendement IA (%)"], reverse=True)[:15]

        # --- PHASE 3 : ÉVALUATION BIOSTEAM ---
        print(f"   [3/3] Technical and Economic Evaluation of 15 finalists...")
        resultats_biosteam_locaux = []
        
        for idx_scenario, scenario in enumerate(elite_locale):
            sys.stdout.write(f"\r      Calculs d'usine : {idx_scenario + 1} / 15 ")
            sys.stdout.flush()

            masse_dechets_entrants = 1000.0 
            masse_nylon_pur = masse_dechets_entrants * (purete_pa6 / 100.0)
            masse_fibres = masse_dechets_entrants - masse_nylon_pur 

            masse_eau = masse_nylon_pur * scenario["Ratio Liq"]
            masse_cat = masse_nylon_pur * (scenario["Cat (wt%)"] / 100.0)
            
            flux_usine = generer_flux_sortie_reacteur(
                masse_pa6_in=masse_nylon_pur, masse_eau_in=masse_eau, type_catalyseur=scenario["Catalyseur"], 
                masse_catalyseur=masse_cat, 
                predictions_IA={'Conversion': min(1.0, (scenario["Rendement IA (%)"]/100.0) + 0.05), 'Rendement_CPL': scenario["Rendement IA (%)"]/100.0}, 
                masse_fibres=masse_fibres, nom_solvant=scenario["Solvant"]
            )
            
            try:
                kpi = orchestrateur_usine(flux_usine, scenario["Catalyseur"], scenario["Réacteur"], scenario["Temp (°C)"], scenario["Pression (KPa)"], scenario["Temps (h)"], scenario["Solvant"])
                
                production_cpl = flux_usine.get('Caprolactam', 0)
                revenu = production_cpl * 2.0 
                
                cout_vapeur = kpi.get('Cout_Vapeur_hr',0)
                cout_eau = kpi.get('Cout_Eau_Froide_hr',0)
                cout_solvant = kpi.get('Cout_Solvant_hr',0)
                cout_equipement = kpi.get('Cout_Equipement_hr',0)
                cout_reactifs = kpi.get('Cout_Reactifs_hr',0)
                cout_catalyseur = kpi.get('Cout_Catalyseur_hr',0)

                if kpi.get('Type_Usine', "") == "Neutre":
                    cout_dechets = kpi.get('Dechets_Totaux_kg', 0) * 0.002 
                else:
                    cout_dechets = (kpi.get('Eaux_Usees_kg', 0) * 0.002) + (kpi.get('Dechets_Toxiques_kg', 0) * 0.50) 

                FACTEUR_MARGE = 1.45 
            
                couts_totaux = cout_vapeur + cout_eau + cout_solvant + cout_equipement + cout_reactifs + cout_catalyseur + cout_dechets
            
            # Application de la marge sur le MSP
                if production_cpl > 0:
                    msp = (couts_totaux * FACTEUR_MARGE) / production_cpl
                else:
                    msp = float('inf')
                
                scenario["Profit (€/h)"] = revenu - couts_totaux
                scenario["MSP (€/kg)"] = msp
                scenario["GWP_kgCO2_per_kgCPL"] = kpi.get('GWP_kgCO2_per_kgCPL', 0.0)
                scenario["Purete Entrante (%)"] = purete_pa6
                resultats_biosteam_locaux.append(scenario)
                
            except Exception as e:
                pass

        print(f"\r      Factory Calculations: 15 / 15 [Completed]       ")   
        
        top_5_local_profit = sorted(resultats_biosteam_locaux, key=lambda x: x.get("Profit (€/h)", -9999), reverse=True)[:5]
        tous_les_gagnants_mondiaux.extend(top_5_local_profit)

    # =====================================================================
    # PHASE FINALE : BATAILLE ROYALE MONDIALE
    # =====================================================================
    # =====================================================================
    # PHASE 4 : BATAILLE ROYALE MONDIALE AVEC CRITÈRE AU CHOIX
    # =====================================================================
    print("\n" + "="*90)
    print("  STRATÉGIE D'OPTIMISATION ")
    print(" [1] Maximizing Profit (Economics)")
    print(" [2] Minimizing the Carbon Footprint (Environmental)")
    choix_opti = input(" -> Your Choice of Strategy (1/2) : ")
    
    if choix_opti == "2":
        classement_final = sorted(tous_les_gagnants_mondiaux, key=lambda x: x.get("GWP_kgCO2_per_kgCPL", 999))
        titre = "ENVIRONMENTAL STRATEGY (MINIMUM GWP)"
    else:
        classement_final = sorted(tous_les_gagnants_mondiaux, key=lambda x: x.get("Profit (€/h)", -9999), reverse=True)
        titre = "ECONOMIC STRATEGY (MAXIMUM PROFIT)"

    print(f"\n {titre}")
    print("="*90)
    
    top_5_mondial = classement_final[:5]
    
    for i, res in enumerate(top_5_mondial):
        print(f"\n RANG {i+1} : ** {res['Procédé'].upper()} **")
        print(f"   ->  MSP (Minimum Selling Price) : {res['MSP (€/kg)']:.2f} €/kg de CPL produit")
        print(f"   ->  market profit: {res['Profit (€/h)']:.2f} €/h")
        print(f"   ->  Carbon footprint (GWP)     : {res['GWP_kgCO2_per_kgCPL']:.2f} kg CO2-eq / kg CPL")
        print(f"   ->  Yield (IA)   : {res['Rendement IA (%)']:.2f} %")
        print(f"   ->  Equipment                  : Réacteur = {res['Réacteur']}")
        print(f"   ->  chemistry                     : Catalyseur = {res['Catalyseur']} | Solvant = {res['Solvant']}")
        print(f"   ->  experimental conditions                 : {res['Temp (°C)']:.1f} °C | {res['Pression (KPa)']:.0f} KPa | {res['Temps (h)']:.1f} h | Cat: {res['Cat (wt%)']:.1f} % | Ratio Liq: {res['Ratio Liq']:.1f}")
        print("-" * 80)
            
    fichier_sauvegarde = os.path.join(DOSSIER_TRAVAIL, 'superstructure_resultats.csv')
    df_sauvegarde = pd.DataFrame(top_5_mondial)
    df_sauvegarde = df_sauvegarde.round(2) # Arrondi pour un fichier plus propre
    df_sauvegarde.to_csv(fichier_sauvegarde, mode='a', header=not os.path.exists(fichier_sauvegarde), index=False, sep=';', encoding='utf-8')
    print(f"\n  SUCCESS : The ranking has been saved in: {fichier_sauvegarde}")

if __name__ == "__main__":
    lancer_superstructure_globale()